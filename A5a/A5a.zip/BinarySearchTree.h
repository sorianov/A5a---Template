//===============================================================
// * Program Name: Assignnment 5a
// * Author: Victor Soriano Mendoza
// * Date Written: 05/10/2017
// * Description: Binary Search Tree with basic functionality
//===============================================================
#pragma once
#include <string>
#include <iostream>

using namespace std;

template <typename Type>
struct TreeNode
{
	Type data;
	TreeNode<Type>* left;
	TreeNode<Type>* right;
};

template <typename Type>
class BinarySearchTree
{
private:
	TreeNode<Type>* root;
	TreeNode<Type>* getRoot();
	void traverseInOrder(TreeNode<Type>* root);
	void traversePreOrder(TreeNode<Type>* root);
	void traversePostOrder(TreeNode<Type>* root);

public:
	BinarySearchTree();
	void insert(Type newData);
	void printInOrder();
	void printPreOrder();
	void printPostOrder();
	void batchInsert(Type data[]);



};

template <typename Type>
void BinarySearchTree<Type>::printPostOrder()
{
	traversePostOrder(getRoot());
}

template<typename Type>
inline void BinarySearchTree<Type>::batchInsert(Type data[])
{
	for (int i = 0; i < 14; i++)
	{
		insert(data[i]);
	}
}


template <typename Type>
TreeNode<Type> * BinarySearchTree<Type>::getRoot()
{
	return root;
}

template <typename Type>
void BinarySearchTree<Type>::traverseInOrder(TreeNode<Type> * root)
{
	if (root != nullptr)
	{
		traverseInOrder(root->left);
		cout << root->data << " ";
		traverseInOrder(root->right);
	}
}

template <typename Type>
void BinarySearchTree<Type>::traversePreOrder(TreeNode<Type> * root)
{
	if (root != nullptr)
	{
		cout << root->data << " ";
		traversePreOrder(root->left);
		traversePreOrder(root->right);
	}
}

template <typename Type>
void BinarySearchTree<Type>::traversePostOrder(TreeNode<Type> * root)
{
	if (root != nullptr)
	{
		traversePostOrder(root->left);
		traversePostOrder(root->right);
		cout << root->data << " ";
	}
}

template <typename Type>
BinarySearchTree<Type>::BinarySearchTree()
{
	root = nullptr;
}

template <typename Type>
void BinarySearchTree<Type>::insert(Type newData)
{
	TreeNode<Type>* current = root;
	TreeNode<Type>* currentTrail = current;
	TreeNode<Type>* newNode = new TreeNode<Type>;

	newNode->data = newData;
	newNode->left = nullptr;
	newNode->right = nullptr;

	if (root == nullptr)
		root = newNode;
	else
	{
		while (current != nullptr)
		{
			currentTrail = current;
			if (current->data > newData)
				current = current->left;
			else
				current = current->right;
		}

		if (currentTrail->data > newData)
			currentTrail->left = newNode;
		else
			currentTrail->right = newNode;
	}


}

template <typename Type>
void BinarySearchTree<Type>::printInOrder()
{
	traverseInOrder(getRoot());
}

template <typename Type>
void BinarySearchTree<Type>::printPreOrder()
{
	traversePreOrder(getRoot());
}